#ifndef _BL2_H_
#define _BL2_H_

int gi_bl2_sign_img(char const *fin, char const *fout);
int gi_bl2_unsign_img(char const *fin, char const *fout);

#endif
